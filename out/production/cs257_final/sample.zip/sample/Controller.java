package sample;

import javafx.event.ActionEvent;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.geometry.Point2D;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.shape.Rectangle;


public class Controller implements EventHandler<KeyEvent>{
    public Group terrainGroup;
    private TerrainModel terrainModel;
    private TerrainView terrainView;
    public Group TankGroup;
    private TankView tankView;

    public Controller() {
    }

    public void initialize() {
        for (Node node : this.terrainGroup.getChildren()) {
            this.terrainView = (TerrainView)node;
            this.terrainModel = new TerrainModel();
            this.terrainView.setTerrainModel(this.terrainModel);
            this.terrainView.update();
        }

        this.tankView = new TankView();
        for (Node node : this.TankGroup.getChildren()) {
            this.tankView = (TankView)node;
            // tank_view.setTerrainModel(this.terrainModel);
            this.tankView.update();
        }
    }

    @Override
    public void handle(KeyEvent keyEvent) {
        System.out.println("You pressed a key");
        KeyCode code = keyEvent.getCode();
        double stepSize = 10.0;
        int xLeftShift = this.terrainView.getXLeftShift();
        if (code == KeyCode.LEFT || code == KeyCode.A) {
            System.out.println("You pressed the left arrow key");
            if (xLeftShift > stepSize) {
                this.terrainView.setXLeftShift((int) (this.terrainView.getXLeftShift() + stepSize));
            } else {
                this.terrainView.setXLeftShift(0);
            }
            keyEvent.consume();
            this.terrainView.update();
        }
        if (code == KeyCode.RIGHT || code == KeyCode.D) {
            System.out.println("You pressed the right arrow key");
            if ((this.terrainView.getWidth()-xLeftShift) > stepSize) {
                this.terrainView.setXLeftShift((int) (this.terrainView.getXLeftShift() - stepSize));
            } else {
                this.terrainView.setXLeftShift(0);
            }
            keyEvent.consume();
            this.terrainView.update();
        }
    }
}
