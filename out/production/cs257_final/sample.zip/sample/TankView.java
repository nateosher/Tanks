package sample;

import javafx.fxml.FXML;
import javafx.scene.Group;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import org.w3c.dom.css.Rect;

/**
 * Created by Nate on 5/28/15.
 */
public class TankView extends Group{
    private TankModel tank;
    private Rectangle tankBody;

    public TankView(){
        this.tank = new TankModel();
        this.tankBody = new Rectangle(0, 0, this.getTank().getWidth(), this.getTank().getHeight());
        this.tankBody.setFill(this.getTank().getTankCol());
    }

    public TankModel getTank(){ return this.tank; }

    public Rectangle getBody(){ return this.tankBody; }

    public void update(){
        this.getChildren().clear();
        this.getChildren().add(this.getBody());
    }
}